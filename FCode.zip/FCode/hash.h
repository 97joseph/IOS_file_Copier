#ifndef _HASH_H_
#define _HASH_H_

// Hash manipulation helper functions
char *hash(FILE *f);

#endif // _HASH_H_//
